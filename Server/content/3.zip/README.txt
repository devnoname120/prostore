This Homebrew is an entry for the PSP Genesis competition 2011,
sponsored by npt, psp-hacks.com, pspgen.com, pspslimhacks.com,
exophase.com, pspcustomfirmware.com, daxhordes.org, gamegaz.jp,
xtreamlua.com and wololo.net

-----------------------
---- Desert Stunts ----
-----------------------

by gorglucks


-----------------------
------ Credits --------
-----------------------

* Race cars :
http://www.tutorialsforblender3d.com/Models/LowPolyCar/LowPoly_Car.html
Under Creative Commons Attribution 3.0 Unported License (CC BY 3.0)

* Police car :
http://virtualworlds.wikia.com/wiki/Police_car

* Music :
http://www.jamendo.com/fr/track/23560
by Zeropage
Under Creative Commons Attribution 3.0 Unported (CC BY 3.0)








