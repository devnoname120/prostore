VISIT PSP-HACKS.COM FORUMS & CHECK OUT MY OFFICIAL RELEASE THREAD FOR MORE INFO!

THANKS! , 
BRICK.

#signed with psp extra tool to work with and without hen/cfw regards 

more ofw homebrews ( a lot compressed ;) @ 
http://wololo.net/talk/viewtopic.php?f=2&t=1879&sid=cee9a20d91f861e58d8d5a09f7340ab3 #